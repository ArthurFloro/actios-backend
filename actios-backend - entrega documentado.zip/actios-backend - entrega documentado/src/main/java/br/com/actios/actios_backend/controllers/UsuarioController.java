package br.com.actios.actios_backend.controllers;

import br.com.actios.actios_backend.dto.LoginDTO;
import br.com.actios.actios_backend.dto.UsuarioDTO;
import br.com.actios.actios_backend.model.Usuario;
import br.com.actios.actios_backend.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Controlador REST para operações relacionadas a usuários.
 * <p>
 * Mapeado para a rota base "/api/usuarios" e fornece endpoints para
 * gerenciamento de usuários, incluindo cadastro, autenticação e CRUD completo.
 *
 * @author Equipe Actios
 * @version 1.0
 * @since 2023-08-30
 */
@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    private final UsuarioService usuarioService;

    /**
     * Construtor com injeção de dependência do serviço de usuários.
     *
     * @param usuarioService Serviço contendo a lógica de negócios para usuários
     */
    @Autowired
    public UsuarioController(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    /**
     * Cadastra um novo usuário no sistema.
     *
     * @param usuario Objeto Usuario contendo os dados para cadastro
     * @return ResponseEntity com o Usuario cadastrado
     * @throws Exception Se ocorrer erro durante o cadastro (ex: email já existente)
     */
    @PostMapping("/cadastrar")
    public ResponseEntity<Usuario> criarUsuario(@RequestBody Usuario usuario) throws Exception {
        Usuario novoUsuario = usuarioService.cadastrar(usuario);
        return ResponseEntity.ok(novoUsuario);
    }

    /**
     * Lista todos os usuários cadastrados no formato DTO.
     *
     * @return ResponseEntity contendo lista de UsuarioDTO
     */
    @GetMapping("/listar")
    public ResponseEntity<List<UsuarioDTO>> listarUsuarios() {
        List<Usuario> usuarios = usuarioService.listarTodos();
        List<UsuarioDTO> usuariosDTO = usuarios.stream()
                .map(UsuarioDTO::fromUsuario)
                .collect(Collectors.toList());
        return ResponseEntity.ok(usuariosDTO);
    }

    /**
     * Busca um usuário específico pelo ID.
     *
     * @param id ID do usuário a ser buscado
     * @return ResponseEntity com o Usuario encontrado
     * @throws Exception Se o usuário não for encontrado
     */
    @GetMapping("/{id}")
    public ResponseEntity<UsuarioDTO> buscarPorId(@PathVariable Integer id) throws Exception {
        Usuario usuario = usuarioService.buscarPorId(id);
        return ResponseEntity.ok(UsuarioDTO.fromUsuario(usuario));
    }

    /**
     * Atualiza os dados de um usuário existente.
     *
     * @param usuario Objeto Usuario com os dados atualizados
     * @return ResponseEntity com o Usuario atualizado
     * @throws Exception Se o usuário não existir ou ocorrer erro na atualização
     */
    @PutMapping("/atualizar")
    public ResponseEntity<Usuario> atualizarUsuario(@RequestBody Usuario usuario) throws Exception {
        Usuario atualizado = usuarioService.atualizar(usuario);
        return ResponseEntity.ok(atualizado);
    }

    /**
     * Exclui um usuário pelo ID.
     *
     * @param id ID do usuário a ser excluído
     * @return ResponseEntity vazio com status 204 (No Content)
     * @throws Exception Se o usuário não existir ou ocorrer erro na exclusão
     */
    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<Void> excluirUsuario(@PathVariable Integer id) throws Exception {
        usuarioService.excluir(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Autentica um usuário com email e senha.
     *
     * @param loginDTO DTO contendo credenciais de login (email e senha)
     * @return ResponseEntity com UsuarioDTO do usuário autenticado
     */
    @PostMapping("/login")
    public ResponseEntity<UsuarioDTO> autenticar(@RequestBody LoginDTO loginDTO) {
        Usuario usuario = usuarioService.autenticar(loginDTO.getEmail(), loginDTO.getSenha());
        return ResponseEntity.ok(UsuarioDTO.fromUsuario(usuario));
    }
}