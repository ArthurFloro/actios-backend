package br.com.actios.actios_backend.controllers;

import br.com.actios.actios_backend.model.Curso;
import br.com.actios.actios_backend.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
@CrossOrigin(origins = "*")
public class CursoController {

    @Autowired
    private CursoService cursoService;

    // GET - Listar todos os cursos
    @GetMapping("/listar")
    public List<Curso> listarTodos() {
        return cursoService.listarTodos();
    }

    // GET - Buscar curso por ID
    @GetMapping("/{id}")
    public ResponseEntity<Curso> buscarPorId(@PathVariable Integer id) {
        return cursoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST - Cadastrar novo curso
    @PostMapping("/cadastrar")
    public Curso criar(@RequestBody Curso curso) {
        return cursoService.salvar(curso);
    }

    // PUT - Atualizar curso
    @PutMapping("/atualizar")
    public ResponseEntity<Curso> atualizar(@RequestBody Curso curso) {
        try {
            return ResponseEntity.ok(cursoService.atualizar(curso.getId(), curso));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE - Excluir curso
    @DeleteMapping("/excluir/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Integer id) {
        cursoService.deletar(id);
        return ResponseEntity.noContent().build();
    }
}
