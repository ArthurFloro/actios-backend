package br.com.actios.actios_backend.service;

import br.com.actios.actios_backend.enums.FormatoEvento;
import br.com.actios.actios_backend.model.Evento;
import br.com.actios.actios_backend.model.EventoDetalhe;
import br.com.actios.actios_backend.repositorys.EventoDetalheRepository;
import br.com.actios.actios_backend.repositorys.EventoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Collections;

@Service
public class EventoDetalheService {
    
    @Autowired
    private EventoDetalheRepository detalheRepository;
    
    @Autowired
    private EventoRepository eventoRepository;

    @Transactional
    public EventoDetalhe salvar(EventoDetalhe detalhe) {
        if (detalhe.getEvento() == null || detalhe.getEvento().getIdEvento() == null) {
            throw new IllegalArgumentException("Evento é obrigatório");
        }
        
        Evento evento = eventoRepository.findById(detalhe.getEvento().getIdEvento())
                .orElseThrow(() -> new RuntimeException("Evento não encontrado"));
        
        detalhe.setEvento(evento);
        return detalheRepository.save(detalhe);
    }

    public EventoDetalhe buscarPorEvento(Integer idEvento) {
        return detalheRepository.findById(idEvento)
                .orElseThrow(() -> new RuntimeException("Detalhes do evento não encontrados"));
    }

    public List<EventoDetalhe> listarTodos() {
        return detalheRepository.findAll();
    }

    public List<EventoDetalhe> listarPorFormato(FormatoEvento formato) {
        return detalheRepository.findByFormato(formato);
    }

    public List<EventoDetalhe> listarPorCertificado(Boolean certificado) {
        return detalheRepository.findByCertificado(certificado);
    }

    public List<EventoDetalhe> listarPorValorMaximo(BigDecimal valorMax) {
        return detalheRepository.findByValorLessThanEqual(valorMax);
    }

    public List<EventoDetalhe> listarPorDataFimApos(LocalDate data) {
        return detalheRepository.findByDataFimGreaterThanEqual(data);
    }

    @Transactional
    public void atualizar(Integer idEvento, EventoDetalhe detalheAtualizado) {
        EventoDetalhe detalhe = detalheRepository.findById(idEvento)
                .orElseThrow(() -> new RuntimeException("Detalhes do evento não encontrados"));
        
        detalhe.setDataFim(detalheAtualizado.getDataFim());
        detalhe.setFormato(detalheAtualizado.getFormato());
        detalhe.setCertificado(detalheAtualizado.getCertificado());
        detalhe.setValor(detalheAtualizado.getValor());
        
        detalheRepository.save(detalhe);
    }
}
