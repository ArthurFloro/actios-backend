package br.com.actios.actios_backend.model;

import jakarta.persistence.*;

@Entity
@Table(name = "vinculo_curso_usuario")
@IdClass(VinculoCursoUsuarioId.class)
public class VinculoCursoUsuario {
    
    @Id
    @ManyToOne
    @JoinColumn(name = "id_usuario")
    private Usuario usuario;
    
    @Id
    @ManyToOne
    @JoinColumn(name = "id_curso")
    private Curso curso;

    public VinculoCursoUsuario() {}
    
    public VinculoCursoUsuario(Usuario usuario, Curso curso) {
        this.usuario = usuario;
        this.curso = curso;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }
}
