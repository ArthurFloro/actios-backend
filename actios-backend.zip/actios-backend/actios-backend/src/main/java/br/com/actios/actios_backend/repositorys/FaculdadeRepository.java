package br.com.actios.actios_backend.repositorys;

import br.com.actios.actios_backend.model.Faculdade;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FaculdadeRepository extends JpaRepository<Faculdade, Integer> {
}
