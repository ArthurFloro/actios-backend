package br.com.actios.actios_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ActiosBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
