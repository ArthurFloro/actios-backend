package br.com.actios.actios_backend.service;

import br.com.actios.actios_backend.model.RegistroCertificado;
import br.com.actios.actios_backend.model.Usuario;
import br.com.actios.actios_backend.model.Curso;
import br.com.actios.actios_backend.repositorys.RegistroCertificadoRepository;
import br.com.actios.actios_backend.repositorys.UsuarioRepository;
import br.com.actios.actios_backend.repositorys.CursoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Service
public class RegistroCertificadoService {
    
    @Autowired
    private RegistroCertificadoRepository registroCertificadoRepository;
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private CursoRepository cursoRepository;

    @Transactional
    public RegistroCertificado criarRegistroCertificado(Integer idUsuario, Integer idCurso) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        
        Curso curso = cursoRepository.findById(idCurso)
                .orElseThrow(() -> new RuntimeException("Curso não encontrado"));
        
        // Verificar se já existe certificado para esse usuário e curso
        if (registroCertificadoRepository.findByUsuarioAndCurso(usuario, curso).size() > 0) {
            throw new RuntimeException("Certificado já existe para este usuário e curso");
        }
        
        RegistroCertificado registro = new RegistroCertificado();
        registro.setUsuario(usuario);
        registro.setCurso(curso);
        
        // Gerar código de validação único
        String codigoValidacao = UUID.randomUUID().toString();
        registro.setCodigoValidacao(codigoValidacao);
        
        return registroCertificadoRepository.save(registro);
    }

    public RegistroCertificado validarCertificado(String codigoValidacao) {
        RegistroCertificado certificado = registroCertificadoRepository.findByCodigoValidacao(codigoValidacao);
        if (certificado == null) {
            throw new RuntimeException("Certificado não encontrado ou inválido");
        }
        return certificado;
    }

    public List<RegistroCertificado> listarPorUsuario(Integer idUsuario) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        
        return registroCertificadoRepository.findByUsuario(usuario);
    }

    public List<RegistroCertificado> listarPorCurso(Integer idCurso) {
        Curso curso = cursoRepository.findById(idCurso)
                .orElseThrow(() -> new RuntimeException("Curso não encontrado"));
        
        return registroCertificadoRepository.findByCurso(curso);
    }

    public long contarPorUsuario(Integer idUsuario) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        
        return registroCertificadoRepository.countByUsuario(usuario);
    }

    public long contarPorCurso(Integer idCurso) {
        Curso curso = cursoRepository.findById(idCurso)
                .orElseThrow(() -> new RuntimeException("Curso não encontrado"));
        
        return registroCertificadoRepository.countByCurso(curso);
    }

    public List<RegistroCertificado> listarPorUsuarioECurso(Integer idUsuario, Integer idCurso) {
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new RuntimeException("Usuário não encontrado"));
        
        Curso curso = cursoRepository.findById(idCurso)
                .orElseThrow(() -> new RuntimeException("Curso não encontrado"));
        
        return registroCertificadoRepository.findByUsuarioAndCurso(usuario, curso);
    }
}
