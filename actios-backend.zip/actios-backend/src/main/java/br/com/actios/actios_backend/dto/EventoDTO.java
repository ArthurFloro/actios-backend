package br.com.actios.actios_backend.dto;

import br.com.actios.actios_backend.model.Evento;

import java.time.LocalDate;

public class EventoDTO {

    private Integer idEvento;
    private String titulo;
    private String descricao;
    private LocalDate data;
    private String nomeFaculdade;
    private String nomeCategoria;

    public EventoDTO(Evento evento) {
        this.idEvento = evento.getIdEvento();
        this.titulo = evento.getTitulo();
        this.descricao = evento.getDescricao();
        this.data = evento.getData();
        this.nomeFaculdade = evento.getFaculdade() != null ? evento.getFaculdade().getNome() : null;
        this.nomeCategoria = evento.getCategoria() != null ? evento.getCategoria().getNome() : null;
    }

    public Integer getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(Integer idEvento) {
        this.idEvento = idEvento;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public String getNomeFaculdade() {
        return nomeFaculdade;
    }

    public void setNomeFaculdade(String nomeFaculdade) {
        this.nomeFaculdade = nomeFaculdade;
    }

    public String getNomeCategoria() {
        return nomeCategoria;
    }

    public void setNomeCategoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }
}

