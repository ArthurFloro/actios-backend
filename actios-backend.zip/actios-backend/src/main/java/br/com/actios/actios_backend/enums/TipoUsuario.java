package br.com.actios.actios_backend.enums;

public enum TipoUsuario {
    ALUNO,
    FACULDADE
}
