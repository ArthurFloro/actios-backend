package br.com.actios.actios_backend.controllers;

import br.com.actios.actios_backend.enums.FormatoEvento;
import br.com.actios.actios_backend.model.EventoDetalhe;
import br.com.actios.actios_backend.service.EventoDetalheService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/eventos-detalhes")
public class EventoDetalheController {
    
    @Autowired
    private EventoDetalheService detalheService;

    @PostMapping("/salvar")
    public ResponseEntity<EventoDetalhe> salvar(@RequestBody EventoDetalhe detalhe) {
        EventoDetalhe salvo = detalheService.salvar(detalhe);
        return ResponseEntity.ok(salvo);
    }

    @GetMapping("/{idEvento}")
    public ResponseEntity<EventoDetalhe> buscarPorEvento(@PathVariable Integer idEvento) {
        EventoDetalhe detalhe = detalheService.buscarPorEvento(idEvento);
        return ResponseEntity.ok(detalhe);
    }

    @GetMapping("/listar")
    public ResponseEntity<List<EventoDetalhe>> listarTodos() {
        List<EventoDetalhe> detalhes = detalheService.listarTodos();
        return ResponseEntity.ok(detalhes);
    }

    @GetMapping("/formato/{formato}")
    public ResponseEntity<List<EventoDetalhe>> listarPorFormato(@PathVariable String formato) {
        List<EventoDetalhe> detalhes = detalheService.listarPorFormato(FormatoEvento.fromValue(formato));
        return ResponseEntity.ok(detalhes);
    }

    @GetMapping("/certificado/{certificado}")
    public ResponseEntity<List<EventoDetalhe>> listarPorCertificado(@PathVariable Boolean certificado) {
        List<EventoDetalhe> detalhes = detalheService.listarPorCertificado(certificado);
        return ResponseEntity.ok(detalhes);
    }

    @GetMapping("/valor-max/{valorMax}")
    public ResponseEntity<List<EventoDetalhe>> listarPorValorMaximo(@PathVariable BigDecimal valorMax) {
        List<EventoDetalhe> detalhes = detalheService.listarPorValorMaximo(valorMax);
        return ResponseEntity.ok(detalhes);
    }

    @GetMapping("/data-fim/{data}")
    public ResponseEntity<List<EventoDetalhe>> listarPorDataFimApos(@PathVariable String data) {
        LocalDate dataFim = LocalDate.parse(data);
        List<EventoDetalhe> detalhes = detalheService.listarPorDataFimApos(dataFim);
        return ResponseEntity.ok(detalhes);
    }

    @PutMapping("/atualizar/{idEvento}")
    public ResponseEntity<Void> atualizar(
            @PathVariable Integer idEvento,
            @RequestBody EventoDetalhe detalheAtualizado) {
        detalheService.atualizar(idEvento, detalheAtualizado);
        return ResponseEntity.noContent().build();
    }
}
